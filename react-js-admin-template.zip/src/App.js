import { Routes, Route } from 'react-router-dom'
import { About } from './components/About'
import { Footer } from './components/Footer';
import { Home } from './components/Home'
import { Navbar } from './components/Navbar'
import { Sidebar } from './components/Sidebar';
// import './App.css';

function App() {
  return (
    <>
      <div className="sb-nav-fixed">
          <Navbar />
          <div id="layoutSidenav">
              <div id="layoutSidenav_nav">
                  <Sidebar />
              </div>
              <div id="layoutSidenav_content">
                  <main>
                      Master File
                  </main>
                  <Footer />
              </div>
          </div>
      </div>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='about' element={<About />} />
      </Routes>
    </>
  );
}

export default App;
